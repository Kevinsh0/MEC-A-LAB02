package lab2_3.pkg3;
/**
 *
 * @author Kevin
 */
public class Lab2_33 {

    public static void main(String[] args) {
        double arreglo [] = new double [4];
        double aux =0;
         for (int i = 0; i < arreglo.length; i++)
         {
             arreglo[i] = Math.random()*101;
         }
         
         Burbuja(arreglo, aux);
         insercion (arreglo);
         seleccion (arreglo, aux); 
         imprimirArreglo(arreglo);
         mergeSort(arreglo,0,(arreglo.length-1));
         imprimirArreglo(arreglo);
        
    }
    

    public static void seleccion (double arreglo[], double aux)
    {
        int minimo = 0;
         System.out.println("\nMETODO SELECCION\n");
        for (int i = 0; i < arreglo.length; i++)
        {
            System.out.print(arreglo[i] + " ");
        }
                                                                                  //{2,4,5,1,6}
        for (int i = 0; i < arreglo.length; i++)
        {
            minimo=i;
            for (int j = i+1; j < arreglo.length; j++)
            {
                if (arreglo[j] < arreglo [minimo])
                    minimo = j;
            }
            aux = arreglo[i];
            arreglo [i] = arreglo [minimo];
            arreglo [minimo] = aux;
            
         }
        
        System.out.println(" ");
        for (int i = 0; i < arreglo.length; i++)
        {
            System.out.print(arreglo[i] + " ");
        }
        
        
    }
    
    public static void insercion (double arreglo[])
    {
        System.out.println("\nMETODO INSERCION\n");
        int auxo; double aux;
       //MOSTRAR ARREGLO INICIAL
        for (int i = 0; i < arreglo.length; i++)
        {
            System.out.print(arreglo[i] + " ");
        }
         System.out.println("  ");
         
        for (int i=0; i < arreglo.length; i++)
        {
            auxo= i;
            aux = arreglo [i];
            while (auxo > 0 && aux < arreglo[auxo -1])
            {
                arreglo[auxo] = arreglo [auxo -1];
                auxo--;
            }
            arreglo[auxo] = aux;
        }
        
        
        for (int i = 0; i < arreglo.length; i++)
        {
            System.out.print(arreglo[i] + " ");
        }
    }
    
    public static void Burbuja (double arreglo [], double aux)
    {     
             System.out.println("\nMETODO BURBUJA\n");
            //Mostrar Array inicial
            for (int i = 0; i < arreglo.length; i++)
                System.out.println(arreglo[i] +" ");  
            System.out.println("  ");
            
          
            for (int i = 0; i < arreglo.length; i++)
            {
                for (int j=0; j < arreglo.length-1; j++)
                {
                    if(arreglo[j+1] < arreglo [j])
                        {
                            aux = arreglo [j];
                            arreglo [j] = arreglo [j+1];
                            arreglo [j+1] = aux;
                        }
                }

            }
            
            
            //MOSTRAR ARREGLO ORDENADO
            for (int i = 0; i < arreglo.length; i++)
                System.out.println(arreglo[i] +" ");   
            
}
        public static void imprimirArreglo (double arreglo [])
    { System.out.println("\nMETODO MERGESORT\n");
        for (int i = 0; i< arreglo.length; i++)
        {
            System.out.println(arreglo [i] + " ");
        }
        System.out.println("");
            
    }
    
    public static void merge (double arreglo [], int inicio, int mitad, int fin)
    {
        int i,j,k;
        int elementosIzq = mitad - inicio +1;
        int elementosDer = fin - mitad;
        double izquierda[] = new double [elementosIzq];
        double derecha[] = new double [elementosDer];
        for ( i = 0; i < elementosIzq; i++)
        {
            izquierda[i] = arreglo [inicio+i];
        }
        for ( j = 0; j < elementosDer; j++)
        {
            derecha [j] = arreglo [mitad + 1 + j];   
        }
        i=0; j=0; k =inicio;
     
        while (i<elementosIzq && j < elementosDer)
        {
            if (izquierda [i] <= derecha [j] )
            {
                arreglo [k] = izquierda [i];
                i++;
            }
            else
            { 
                arreglo[k] = derecha [j];
                j++;
            } 
            k++;

            while (j < elementosDer)
            {
                arreglo [k] = derecha [j];
                j++;
                k++;
            }

               while (i < elementosIzq)
            {
                arreglo [k] = izquierda [i];
                i++;
                k++;
            }

        }
 
    }

    public static void mergeSort(double arreglo [], int inicio, int fin)
            {
                if(inicio <  fin)
                {
                    int mitad = inicio + (fin - inicio)/2;
                    mergeSort (arreglo, inicio,mitad);
                    mergeSort (arreglo, mitad+1, fin);
                    merge (arreglo, inicio, mitad, fin);        
                }
            }
    
}
