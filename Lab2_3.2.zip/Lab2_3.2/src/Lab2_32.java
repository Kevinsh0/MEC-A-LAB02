import java.util.Scanner;

public class Lab2_32{

    static Scanner entrada = new Scanner (System.in);
    public static void main(String args[]) {
        String linea;
        char[] caracteres;
        int seleccion = 0;
        System.out.println("Ingrese una línea de texto");
        linea = entrada.nextLine();
        caracteres = linea.toCharArray();
        while (seleccion != 3)
        {
          System.out.println("Seleccion de proceso: \n1.Reemplazo\n2.Invertir\n3.Finalizar");
          seleccion = entrada.nextInt();
            if(seleccion ==1)
                reemplazo(caracteres);
            else if (seleccion == 2)
            invertir (caracteres);
        }
    }
    
    public static void reemplazo(char [] caracteres)
    {
        char letra = 'a';
        int reps = 0,aux = 1;
        System.out.println("El arreglo original es el siguiente: " );
        for (int i = 0; i < caracteres.length; i++)
        {
            System.out.print(caracteres[i]);
        }
        for (int i = 0 ; i < caracteres.length; i++)
        { 
            reps = 0;
            for(int j = 1; j < caracteres.length; j++)
            {
                if(caracteres [i] == caracteres [j] && caracteres [i] != ' ')
                    reps ++;
            }
            
            if(reps > aux)
            {
             aux = reps;
             letra = caracteres[i];
             System.out.println("\nREPS: " + aux + " " + letra);
            }
            reps = 0;
        }
        
       // System.out.println("\nREPS: " + aux + " " + letra);
          System.out.print("\nEl arreglo modificado es el siguiente: ");
        for (int i = 0;  i < caracteres.length; i++)
        {
            if(caracteres[i] == 'a'||caracteres[i] == 'e'||caracteres[i] == 'i'||caracteres[i] =='o'||caracteres[i] == 'u')
                caracteres [i] = letra;  
            System.out.print(caracteres[i]);
        } 
            System.out.println("");
    }
    
    public static void invertir(char[] caracteres)
    {
        //INVERTIR ARREGLO:
        int j = caracteres.length;    
        char aux;
       
        for (int i = 0; i < j; i++)
            {
                aux = caracteres [i];
                caracteres [i] = caracteres [j-1];
                caracteres [j-1]  =aux;
                j--;
            }
            System.out.println("\nArreglo modificado:");
             for (int i = 0; i < caracteres.length; i++)
            {
                System.out.print(caracteres[i]);
            }
             System.out.println("");
    }
}



    
            
   
